// This file is no longer needed as AdminLayout.tsx now manages its own layout preference state.
// The context provider and hook are superseded by the logic within AdminLayout.tsx.
