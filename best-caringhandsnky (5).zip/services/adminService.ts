
// This file is no longer needed as payment gateway settings are managed by
// paymentGatewayService.ts using Supabase, instead of localStorage.
// If other admin-wide, non-Supabase settings are needed in the future,
// this file could be repurposed. For now, it can be removed.

// console.log("adminService.ts is deprecated and can be removed.");
